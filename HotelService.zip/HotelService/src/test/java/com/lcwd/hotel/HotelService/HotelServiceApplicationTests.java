package com.lcwd.hotel.HotelService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
